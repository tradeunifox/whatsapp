BASE_URL = "https://whatsapp.tradeunifox.com/api"
DEFAULT_TIMEOUT = 10  # seconds
